//
//  SpaceItem.h
//  Autolayout
//
//  Created by xiaoling on 2018/3/9.
//  Copyright © 2018年 LSJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Masonry.h>


@interface VerticalItem : UIView

@property(nonatomic,strong)UILabel * itemCountLB;
@property(nonatomic,strong)UILabel * itemContentLB;

@end



