//
//  ViewController.m
//  Autolayout
//
//  Created by xiaoling on 2018/3/9.
//  Copyright © 2018年 LSJ. All rights reserved.
//

#import "ViewController.h"
#import "SpaceItem.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
  [super viewDidLoad];
  // Do any additional setup after loading the view, typically from a nib.
    [self configureView];
}

#warning 这个不支持转屏，只是适配不同机型
- (void)configureView{
    NSArray * sections = @[@2,@4,@4];
    for(int i=0;i<sections.count;i++){
        UIView * sectionView = [self configurePerSectionCount:[sections[i] integerValue]];
        sectionView.backgroundColor = [[UIColor lightGrayColor] colorWithAlphaComponent:0.3];
        [self.view addSubview:sectionView];
        
        CGFloat subHorizonSpace = [UIScreen mainScreen].bounds.size.width /3.0;
        [sectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(subHorizonSpace * i);
            make.height.mas_equalTo(150);//随意写的
            make.top.mas_equalTo(100);//随意
        }];
        
        UIView * rightLine = [UIView new];
        rightLine.backgroundColor = [UIColor greenColor];
        [self.view addSubview:rightLine];
        
        [rightLine mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.right.equalTo(sectionView);
            make.width.mas_equalTo(1);
        }];
    }
}


- (UIView *)configurePerSectionCount:(NSInteger)count{
    CGFloat subHorizonSpace = self.view.frame.size.width /3.0;
    CGFloat section1temSpace = subHorizonSpace/count;

    UIView * bgView = [UIView new];
    for(int i=0;i<count;i++){
        VerticalItem * item = [VerticalItem new];
        [bgView addSubview:item];
        
        [item mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(bgView.mas_left).offset(section1temSpace/2.0+i*section1temSpace);
            make.centerY.equalTo(bgView);
            make.height.mas_equalTo(80);//随意写的
            make.width.mas_equalTo(section1temSpace);
        }];
    }
    return bgView;
}




- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
  // Dispose of any resources that can be recreated.
}


@end
