//
//  AppDelegate.h
//  Autolayout
//
//  Created by xiaoling on 2018/3/9.
//  Copyright © 2018年 LSJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

