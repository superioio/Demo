//
//  SpaceItem.m
//  Autolayout
//
//  Created by xiaoling on 2018/3/9.
//  Copyright © 2018年 LSJ. All rights reserved.
//

#import "SpaceItem.h"
@implementation VerticalItem

- (instancetype)init{
    if(self=[super init]){
        [self configureTempData];
    }
    return self;
}

- (void)configureTempData{
    //init
    self.itemCountLB = [UILabel new];
    self.itemCountLB.textAlignment = NSTextAlignmentCenter;
    self.itemCountLB.font = [UIFont systemFontOfSize:18 weight:UIFontWeightBold];
    self.itemCountLB.text = [NSString stringWithFormat:@"%d",arc4random()%10];
    self.itemCountLB.textColor = @[[UIColor redColor],[UIColor blueColor],[UIColor cyanColor],[UIColor purpleColor]][arc4random()%4];
    [self addSubview:self.itemCountLB];
    
    self.itemContentLB = [UILabel new];
    self.itemContentLB.textAlignment = NSTextAlignmentCenter;
    self.itemContentLB.font = [UIFont systemFontOfSize:13 weight:UIFontWeightRegular];
    self.itemContentLB.text = @"po";
    self.itemContentLB.textColor = [UIColor lightGrayColor];
    [self addSubview:self.itemContentLB];
    
    //layout
    CGFloat verticalSpace = 10;
    
    [self.itemCountLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self);
        make.top.equalTo(self);
    }];
    
    [self.itemContentLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.itemCountLB.mas_bottom).offset(verticalSpace);
        make.centerX.equalTo(self);
    }];
    
    
    
}
@end




